# Keep defaults; no custom rules needed for a WebView wrapper.
