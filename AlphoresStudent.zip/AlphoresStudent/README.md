# Alphores AI Student — Android app

A native Android (Kotlin) app that wraps https://student.alphores.ai/ so it runs as a real installable app.

## Features
- Full-screen portal with brand-colored status bar and a loading bar
- Sign-in stays saved (cookies persisted)
- Back button navigates page history, then exits
- Pull down to refresh
- File upload (homework, profile photo) and file downloads (books, reports)
- Camera and microphone access for live classes / doubts when the site asks
- Offline screen with a "Try again" button
- Opens `https://student.alphores.ai/...` links inside the app; other links open in the system browser

## Build the APK
1. Install Android Studio (Koala or newer).
2. File → Open → select this `AlphoresStudent` folder. Let Gradle sync (it creates the Gradle wrapper automatically).
3. To test: connect a phone with USB debugging (or start an emulator) and press Run.
4. To get an installable APK: Build → Build Bundle(s) / APK(s) → Build APK(s).
   The file lands in `app/build/outputs/apk/debug/app-debug.apk`.
5. For Play Store: Build → Generate Signed Bundle / APK, and choose Android App Bundle.

## Customising
- Site URL: `homeUrl` and `appHost` at the top of `MainActivity.kt`
- App name: `res/values/strings.xml`
- Colors: `res/values/colors.xml`
- Icon: `res/drawable/ic_launcher_foreground.xml` (replace with your real logo via Image Asset Studio: right-click `res` → New → Image Asset)
- Package id: `ai.alphores.student` in `app/build.gradle.kts` (change if you publish under your own account)

## Note
This app loads the live website, so it needs an internet connection and updates whenever the site updates. Make sure you have the right to publish an app for this site before releasing it on the Play Store.
